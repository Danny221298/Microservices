package com.javatechie.jwt.api.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatechie.jwt.api.entity.User;
import com.javatechie.jwt.api.repository.UserRepository;

@Service
public class UserLoginServiceImpl implements Userloginservie {

	@Autowired
	UserRepository userRepo;

	@Override
	public User registration(User user) {
		return userRepo.save(user);
	}

}
