package com.javatechie.jwt.api.service;

import com.javatechie.jwt.api.entity.User;

public interface Userloginservie {

	public User registration(User user);
}
