package com.demo.user.service.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.demo.user.service.entities.User;
import com.demo.user.service.exception.ResourcesNotFountException;

@Service
public interface UserService {

	
	User save(User user);
	
	List<User> getAllUser();
	
	User getUSer(String userId) throws ResourcesNotFountException;
}
