package com.demo.user.service.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class ResourcesNotFountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResourcesNotFountException() {

		super("User not fount Exception !!");

	}

	public ResourcesNotFountException(String msg) {

		super(msg);

	}

}
