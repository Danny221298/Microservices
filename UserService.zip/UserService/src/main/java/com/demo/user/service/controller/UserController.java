package com.demo.user.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.user.service.entities.User;
import com.demo.user.service.exception.ResourcesNotFountException;
import com.demo.user.service.services.UserService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping(value = "/users")
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/saveUser")
	public ResponseEntity<User> createUser(@RequestBody User user) {

		ResponseEntity<User> response = null;
		user = userService.save(user);
		return response = new ResponseEntity<User>(user, HttpStatus.CREATED);
	}

	@GetMapping("/{userId}")
	//@CircuitBreaker(name = "ratingHotelBreaker", fallbackMethod = "ratingHotelFallback")
	@RateLimiter(name ="userRateLimiter" ,fallbackMethod = "ratingHotelFallback")
	public ResponseEntity<User> getSingleUser(@PathVariable String userId) throws ResourcesNotFountException {

		User user = userService.getUSer(userId);
		return ResponseEntity.ok(user);

	}

	@GetMapping
	public ResponseEntity<User> ratingHotelFallback(String UserId, Exception ex) {

		User user = User.builder().email("dummuy@email.com").name("dummy").about("This user is dummy").userId("12345")
				.build();
		return ResponseEntity.ok(user);
	}

	@GetMapping("/allUser")
	public ResponseEntity<List<User>> getAllUser() {
		List<User> allUser = userService.getAllUser();

		return ResponseEntity.ok(allUser);

	}
}
