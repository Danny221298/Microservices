package com.demo.user.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.demo.user.service.entities.Hotel;
import com.demo.user.service.entities.Rating;
import com.demo.user.service.entities.User;
import com.demo.user.service.exception.ResourcesNotFountException;
import com.demo.user.service.feign.HotelService;
import com.demo.user.service.repositories.UserRepository;
import com.demo.user.service.services.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RestTemplate restTemplate;

	
	private HotelService hotelService;

	@Override
	public User save(User user) {

		String randomUserID = UUID.randomUUID().toString();
		user.setUserId(randomUserID);
		return userRepository.save(user);
	}

	@Override
	public List<User> getAllUser() {

		return userRepository.findAll();
	}

	@SuppressWarnings("unchecked")
	@Override
	public User getUSer(String userId) throws ResourcesNotFountException {

		User user = userRepository.findById(userId)
				.orElseThrow(() -> new ResourcesNotFountException("User ID not found  ," + userId));

		Rating[] ratingsOfUser = restTemplate
				.getForObject("http://RATING-SERVICE/ratings/getRatingFromUserId/" + user.getUserId(), Rating[].class);

		List<Rating> ratings = Arrays.stream(ratingsOfUser).toList();

		List<Rating> ratinglist = ratings.stream().map(rating -> {

			ResponseEntity<Hotel> forEntity = restTemplate
					.getForEntity("http://HOTEL-SERVICE/hotel/" + rating.getHotelId(), Hotel.class);
			Hotel hotel = forEntity.getBody();

			rating.setHotel(hotel);

			return rating;

		}).collect(Collectors.toList());

		user.setRatings(ratinglist);
		return user;
	}

}
