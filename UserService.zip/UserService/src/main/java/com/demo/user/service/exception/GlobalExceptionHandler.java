package com.demo.user.service.exception;

import org.springframework.boot.autoconfigure.info.ProjectInfoProperties.Build;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.demo.user.service.payload.ApiResponse;



@RestControllerAdvice
public class GlobalExceptionHandler {
	

	@ExceptionHandler(ResourcesNotFountException.class)
	public ResponseEntity<ApiResponse> handleResourseFounDException(ResourcesNotFountException ex)
	{
		
		String message = ex.getMessage();
		ApiResponse response = ApiResponse.builder().message(message).success(true).status(HttpStatus.NOT_FOUND).build();
		return new ResponseEntity<ApiResponse>(response ,HttpStatus.NOT_FOUND);
		
	}

}
