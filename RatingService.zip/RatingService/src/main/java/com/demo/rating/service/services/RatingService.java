package com.demo.rating.service.services;

import java.util.List;

import com.demo.rating.service.entities.Rating;

public interface RatingService {
	
	Rating addRating(Rating rating);
	
	List<Rating> getAllRatings();
	
	List<Rating> getRatingsByUserId(String userId);
	
	List<Rating> getRatingsByHotelId(String hotelId);

	
}
