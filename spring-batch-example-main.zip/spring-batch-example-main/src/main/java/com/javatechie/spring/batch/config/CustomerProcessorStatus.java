package com.javatechie.spring.batch.config;

import org.springframework.batch.item.ItemProcessor;

import com.javatechie.spring.batch.entity.Customer;

public class CustomerProcessorStatus implements ItemProcessor<Customer, Customer> {

	@Override
	public Customer process(Customer customer) throws Exception {
		if (Boolean.FALSE.equals(customer.getStatus())) {
			return customer;
		}
		return null;

	}

}