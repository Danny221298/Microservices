
public class FindOutput {
	
	public static void main(String[] args) {
		
		int i=2;
		
		for(i =0 ;;i++) {
			
			System.out.println("hello");
		}
	}

}
