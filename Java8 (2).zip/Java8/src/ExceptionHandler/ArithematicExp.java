package ExceptionHandler;

public class ArithematicExp {
	public static void div() throws ArithmeticException {

		int a = 20;
		int b = 2;

		int c = a / b;

		System.out.println(c);

		throw new ArithmeticException("Number is divided by zero");

	}

	public static void main(String[] args) {

		div();
	}

}
