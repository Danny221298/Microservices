
public class str3 {
	
	public static void main(String[] args) {

		String s = "SUMITGUND";

    	int c = 0;
	
		for (int i = 0; i < s.length(); i++) {

			if (!Character.isLetterOrDigit(s.charAt(i)) && !Character.isWhitespace(s.charAt(i))) {

				c++;
			}
		}

		if(c==0) {
			System.out.println("No special character  no :" +c);
		}
		else {
			System.out.println("No of special character :" +c);
		}
	
	}

}
