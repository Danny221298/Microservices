package MethodRefrence2;

public class MethodRef {
	
	public static void hello() {
		
		System.out.println("Hello Java User");
	}
	
	public static void main(String[] args) {
		
		MethodFun f1 = MethodRef::hello;
		
		f1.print();
	}

}
