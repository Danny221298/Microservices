package MethodRefrence2;

public interface MethodFun {
	
	public abstract void print();

}
