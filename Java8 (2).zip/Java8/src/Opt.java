import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Opt {
	
	public static void main(String[] args) {
	
		List<String> l1 = Arrays.asList("Ram" ,"Ganga","Bhuvan","Sita");
		
		Optional<String> l2List = l1.stream().filter(a->a.contains("R")).findFirst();
		
		System.out.println(l2List.orElse("No String found"));
		
	}

}
