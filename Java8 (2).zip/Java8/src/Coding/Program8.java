package Coding;

public class Program8 {

	public static void main(String[] args) {

		int arr[] = new int[] { 2, 4, 3, 5, 6, 7, 9, 8 };

		int a[];

		numberEvenOrOdd(arr);

	}

	public static void numberEvenOrOdd(int arr[]) {

		int a[] = new int[arr.length];
		int count = 0;
		for (int i = 0; i < arr.length; i++) {

			if (arr[i] % 2 == 0) {

				a[count] = arr[i];

				count++;
			}
		}
		
		for (int i = 0; i < arr.length; i++) {

			if (arr[i] % 2 != 0) {

				a[count] = arr[i];

				count++;
			}
		}
		
		for(int i=0; i<a.length;i++) {
			System.out.print(a[i]);
		}
	}

}
