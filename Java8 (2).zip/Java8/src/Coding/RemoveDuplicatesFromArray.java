package Coding;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveDuplicatesFromArray {
	public static void main(String[] args) {
		
	List<Integer> l1 = Arrays.asList(23,45,32,56,78,23);
	
	HashSet<Integer> h1 = new HashSet<>();	
	
	List<Integer> a1 = l1.stream().filter(a -> ! h1.add(a)).collect(Collectors.toList());
	
	System.out.println(a1);
	
	}
}
