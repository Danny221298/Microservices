package Coding;

public class Program6 {

	public static void main(String[] args) {

		String str = "Hello I am java Student From Capgemini";

		int mid = str.length() / 2;
		String lo = "";
		String Up = "";

		for (int i = 0; i < str.length(); i++) {

			if (i < mid) {

				lo = lo + Character.toLowerCase(str.charAt(i));

			} else {
				Up = Up + Character.toUpperCase(str.charAt(i));

			}

		}

		System.out.println(lo + Up);
	}

}
