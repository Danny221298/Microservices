package Coding;

import java.util.List;

public class Program1 {

	public static void main(String[] args) {

		List<Integer> l1Integers = new ArrayList<Integer>((o1 ,o2)->(o1>o2)?-1:(o1<o2)?1:0)));
		
		l1Integers.add(23);
		l1Integers.add(34);
		l1Integers.add(12);
		l1Integers.add(21);
		l1Integers.add(67);
		
		
		System.out.println(l1Integers);
	}
}
