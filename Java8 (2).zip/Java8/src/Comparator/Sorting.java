package Comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sorting {
	public static void main(String[] args) {

		List<Integer> l2Integers = new ArrayList<Integer>();
		l2Integers.add(23);
		l2Integers.add(11);
		l2Integers.add(65);
		l2Integers.add(7);
		l2Integers.add(45);
		l2Integers.add(65);

		System.out.println("Before Sorting " + l2Integers);

		Collections.sort(l2Integers, (o1,o2)->(o1 > o2) ? -1 : (o1 < 02) ? 1 : 0);

		System.out.println("After Sorting  " + l2Integers);
	}

}
