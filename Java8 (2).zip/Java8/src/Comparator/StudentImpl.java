package Comparator;

import java.util.Comparator;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

public class StudentImpl {
	
	public static void main(String[] args) {
		
	  List<Students> student = List.of(new Students("Aalok", 76, "758364854585"),
			  new Students("Ram", 86, "7453465487"),
			  new Students("Funa", 94, "98675236487"),
			  new Students("Sham", 99, "98967806708"),
			  new Students("John", 64, "8956757647534875"));
	
	  List<Students> s1 = student.stream().filter(a->a.getName().startsWith("S")).toList();
	  
	  System.out.println(s1);
	  
	  List<Students> s2 = student.stream().sorted(Comparator.comparing(Students::getName)).toList();
	  
	  System.out.println(s2);
	  
	  OptionalDouble s3 = student.stream().filter(a->a.getMarks() > 80).mapToInt(Students::getMarks).average();
	  
	  System.out.println(s3);
	  
	String n1List = student.stream().map(Students::getName).collect(Collectors.joining(",")).toString();
	
	System.out.println(n1List);
	
	
	}
	
	
}
