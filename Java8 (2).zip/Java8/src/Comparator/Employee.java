package Comparator;

import java.util.List;

public class Employee {
	
	public static void main(String[] args) {
	
		List<String> s1Strings = List.of("Anuj","John","Fredric","Jasmine");
		
		List<String> l1Strings = s1Strings.stream().map(s ->s.toUpperCase()).toList();
		
		System.out.println(l1Strings);
		
	}

}
