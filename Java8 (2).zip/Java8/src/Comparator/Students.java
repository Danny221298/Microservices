package Comparator;

public class Students {
	
	private String name;
	
	private int marks;
	
	private String mobileNo;

	public Students(String name, int marks, String mobileNo) {
		super();
		this.name = name;
		this.marks = marks;
		this.mobileNo = mobileNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return "Students [name=" + name + ", marks=" + marks + ", mobileNo=" + mobileNo + "]";
	}
	
	

}
