
public class Omakr {
	
	static{
	
		System.out.println("Hello");

	}

}
