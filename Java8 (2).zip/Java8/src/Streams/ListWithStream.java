package Streams;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ListWithStream {
	
	public static void main(String[] args) {
		
		List<Integer> a1 = Arrays.asList(23,45,65,34,21,67,89,89,87);
		
		List<Integer> a2= a1.stream().sorted(Comparator.reverseOrder()).distinct().toList();
		
		System.out.println(a2);
		
		List<Integer> a3 =a1.stream().map(m1 -> m1 + 20).toList();
		
		System.out.println(a3);
		
	}

}
