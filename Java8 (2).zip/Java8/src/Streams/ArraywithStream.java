package Streams;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ArraywithStream {
	public static void main(String[] args) {

		List<Integer> s1 = Arrays.asList(23, 21, 45, 33, 67, 87);

		Integer l1Integer = s1.stream().sorted(Comparator.reverseOrder()).distinct().findFirst().get();

		System.out.println(l1Integer);

		Integer l2Integer = s1.stream().sorted(Comparator.naturalOrder()).distinct().findFirst().get();

		System.out.println(l2Integer);

		Double l3Integer = s1.stream().mapToInt(Integer::intValue).average().getAsDouble();

		Integer l4Integer = s1.stream().mapToInt(Integer::intValue).sum();

		System.out.println(l3Integer);

		System.out.println(l4Integer);

		long l5Integer = s1.stream().count();

		System.out.println(l5Integer);

	}

}
