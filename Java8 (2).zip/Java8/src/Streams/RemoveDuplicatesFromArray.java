package Streams;

import java.util.Arrays;
import java.util.List;

public class RemoveDuplicatesFromArray {

	public static void main(String[] args) {

		int arr[] = { 23, 45, 78, 76, 98 };

		int arr1[] = { 21, 32, 45, 76, 89 };

		List<Integer> l1 = Arrays.stream(arr).filter(num1 -> Arrays.stream(arr1)
				.anyMatch(num2 -> num2 == num1)).boxed()
				.toList();

		System.out.println(l1);
	}
}
