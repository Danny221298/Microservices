package FunctionalInterface1;

public class Impl3  {

	public static void main(String[] args) {
			
		Impl i1 = (a,b)->System.out.println(a+b);
		
		i1.add(34, 21);
		
		Impl.add2();
		
		

	}
}

