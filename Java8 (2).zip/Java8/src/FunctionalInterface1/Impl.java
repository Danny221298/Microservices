package FunctionalInterface1;

@FunctionalInterface
public interface Impl{
	
	public abstract void add(int a,int b);
	
	public static void add1() {
		
		System.out.println("Hello this is static");
		
	}
	
	static void add2() {
		
		System.out.println("Hello this is static");
		
		hello();
		
	}
	
	private static void hello() {
		
		System.out.println("This is private inside Static");
	}

	@Override
	String toString();
}
