package FunctionalInterface1;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.function.Supplier;

public class Supplier1 {
	public static void main(String[] args) {
		
		Supplier<Integer> s1 = () -> LocalDateTime.now().getDayOfMonth();
		
		System.out.println("Todays date is " + s1.get());
		
		Supplier<Date> d = () -> new Date();
		
		System.out.println(d.get());
	}

}
