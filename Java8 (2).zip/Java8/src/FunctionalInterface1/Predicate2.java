package FunctionalInterface1;

import java.util.function.Predicate;

public class Predicate2{
	
	public static void main(String[] args) {
		
		Predicate<Integer> p = I -> I>10;
		
		System.out.println(p.test(20));
	}

}
