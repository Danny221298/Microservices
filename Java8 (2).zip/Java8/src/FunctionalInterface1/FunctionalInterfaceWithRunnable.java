package FunctionalInterface1;

import java.util.Comparator;
import java.util.List;

public class FunctionalInterfaceWithRunnable {
	
	public static void main(String[] args) {
		
		Runnable l1 = ()->{
			int a = 20;
			int b = 30;
			System.out.println(a+b);
		};
			
		l1.run();
		
		List<Integer> l1List = List.of(13,46,65,7,5,22);
		
		List<Integer> s1List = l1List.stream().distinct().sorted(Comparator.reverseOrder()).toList();
		
		System.out.println(s1List);
		
	}
	

	


}
