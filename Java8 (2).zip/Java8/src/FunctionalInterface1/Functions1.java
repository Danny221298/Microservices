package FunctionalInterface1;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Functions1 {
	
	public static void main(String[] args) {
		
		Function<String, String> s1 = input -> input.toUpperCase();
		
		System.out.println("Converting String To UpperCase " + s1.apply("Java Developer"));
		
		String str ="Java";
		
		List<String> s11 = Arrays.stream(str.split(""))
				.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
				.entrySet().stream().filter(a-> a.getValue()>1)
				.map(Map.Entry::getKey).collect(Collectors.toList());
		
		System.out.println(s11);
	}

}
