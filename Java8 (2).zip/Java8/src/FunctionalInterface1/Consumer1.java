package FunctionalInterface1;

import java.util.function.Consumer;

public class Consumer1 {
	
	public static void main(String[] args) {
		
		Consumer<String> con = ip -> System.out.println("Converting to UpperCase " + ip.toUpperCase());
		
		con.accept("Java Techi");
		
	}

}
