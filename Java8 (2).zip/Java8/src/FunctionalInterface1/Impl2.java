package FunctionalInterface1;

public class Impl2 {
	public static void main(String[] args) {

		Runnable r1 = () -> {
			for (int i = 1; i <= 10; i++) {

				System.out.println("Table of 5 is : " + i * 5);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};

		Thread t1 = new Thread(r1);

		t1.start();
	}

}
