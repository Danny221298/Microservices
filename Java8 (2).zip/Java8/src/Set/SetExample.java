package Set;

import java.util.HashSet;

public class SetExample {
	
	public static void main(String[] args) {
		
		HashSet<String> h1 = new HashSet<String>();
		
		h1.add("Ram");
		h1.add("Sham");
		h1.add("Ram");
		
		System.out.println(h1);
	
	}

}
