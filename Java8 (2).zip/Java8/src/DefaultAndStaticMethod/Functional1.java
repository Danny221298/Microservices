package DefaultAndStaticMethod;

@FunctionalInterface
public interface Functional1 {
	
	void print();
	
	default void diplay() {
		
		System.out.println("Java Functional interface");
	}
	
	public static void display2() {
		
		System.out.println("Static method inside Functional Interface");
	}
	
	
	

}
