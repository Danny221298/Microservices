package DefaultAndStaticMethod;

public class Default1 implements Functional1 {
	
	public static void main(String[] args) {
		
		Default1 d1 = new Default1();
		
		Functional1  f1 = () ->{
			System.out.println("Print method in Main class");
		};
		
		d1.diplay();
		
		f1.print();
		
		Functional1.display2();
		
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}

	
}
