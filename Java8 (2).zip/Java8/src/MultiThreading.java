
public class MultiThreading extends Thread {

	public void run() {

		for (int i = 101; i < 201; i++)
			System.out.print(" " + i);
		Thread.yield();

	}

	public static void main(String[] args) {

		MultiThreading m1 = new MultiThreading();

		System.out.println("\nTask 1 Started");
		m1.start();
		System.out.print("\nTask 1 done");

		MultiThreading m2 = new MultiThreading();

		System.out.println("\nTask 2 Started");
		m2.start();
		System.out.print("\nTask 2 done");

		MultiThreading m3 = new MultiThreading();

		System.out.println("\nTask 3 Started");
		m3.start();
		System.out.print("\nTask 3 done");

	}

}
