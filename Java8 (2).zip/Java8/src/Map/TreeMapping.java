package Map;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapping {

	public static void main(String[] args) {

		Map<String, String> m = new TreeMap<String, String>();

		m.put("d", "afs");
		m.put("d", "abs");

		String str = "Sachin";
		String str1 = "sachin";

		System.out.println(str.hashCode());
		System.out.println(str1.hashCode());

		System.out.println(m.values());

	}
}
