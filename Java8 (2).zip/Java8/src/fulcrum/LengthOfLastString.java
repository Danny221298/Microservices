package fulcrum;

public class LengthOfLastString {
	
	public static void main(String[] args) {
		
		String str = "Hello I am java user";
		
		String[] words = str.trim().split(" ");
		
		int len =words[ words.length -1].length();
		
		System.out.println(len);
	}

}
