package fulcrum;

public class Find1stAndLastPostionInSortedArray {

	public static void main(String[] args) {

	}

}
