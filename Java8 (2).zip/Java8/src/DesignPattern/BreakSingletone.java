package DesignPattern;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class BreakSingletone {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		Singletone s1 = Singletone.getSingletone();
		System.out.println(s1.hashCode());
		
		Constructor<Singletone> c1 = Singletone.class.getDeclaredConstructor();
		c1.setAccessible(true);
		Singletone s2 = c1.newInstance();
		System.out.println(s2.hashCode());
		

	}

}
