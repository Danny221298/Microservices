package DesignPattern;

public class Singletone {
	
	private static Singletone singletone;

	private Singletone() {
	
	}
	
	public static Singletone getSingletone() {
		
		if(singletone == null) {
			
			singletone = new Singletone();
			
		}
		
		return singletone;
		
	}
	
	

}
