package DesignPattern;

public interface factoryInterface {
	
	int salary();

}
