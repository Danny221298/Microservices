package DesignPattern;

public class CallingFactory {
	
	public static void main(String[] args) {
		
		factoryInterface emp = FactoryDesign.getEmployee("Java Devleoper");
		System.out.println(emp.salary());
		
	}

}
