package DesignPattern;

public class PythonDevleper implements factoryInterface {

	@Override
	public int salary() {
      System.out.println("Salary of python dev is");
		return 50000;
	}
	

}
