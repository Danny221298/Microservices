package DesignPattern;

public class JavaDevleoper implements factoryInterface{

	@Override
	public int salary() {
		System.out.println("Salary of java devleoper");
		return 70000;
	}

}
