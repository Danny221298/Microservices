package DesignPattern;

public class BuilderMain {
	
	public static void main(String[] args) {
		
		User b1 =	new User.UserBuilder()
				.setEmpId("12").
				setEmpName("Danny").
				setEmpMail("danny@gmail.com").build();
	
		System.out.println(b1);
	}

}
