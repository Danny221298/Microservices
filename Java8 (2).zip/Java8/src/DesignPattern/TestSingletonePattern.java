package DesignPattern;

public class TestSingletonePattern {

	public static void main(String[] args) {

		Singletone s1 = Singletone.getSingletone();

		System.out.println(s1.hashCode());

		Singletone s2 = Singletone.getSingletone();

		System.out.println(s2.hashCode());
	}

}
