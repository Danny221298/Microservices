package DesignPattern;

public class FactoryDesign {
	
	public static factoryInterface getEmployee(String empType) {
		
		if(empType.trim().equalsIgnoreCase("Java Devleoper")) {
			 return new JavaDevleoper();
		}
		
		if(empType.trim().equalsIgnoreCase("Python Devleper")) {
			 return new PythonDevleper();
		}
		return null;
		
	}

}
