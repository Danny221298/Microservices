package DesignPattern;

public class User {

	private final String empId;
	private final String empName;
	private final String empMail;

	public User(UserBuilder user) {

		this.empId = user.empId;
		this.empName = user.empName;
		this.empMail = user.empMail;

	}

	public String getEmpId() {
		return empId;
	}

	public String getEmpName() {
		return empName;
	}

	public String getEmpMail() {
		return empMail;
	}

	@Override
	public String toString() {
		return this.empId + " ," + this.empName + "," + this.empMail;
	}

	static class UserBuilder {

		private String empId;
		private String empName;
		private String empMail;

		public UserBuilder() {

		}

		public UserBuilder setEmpId(String empId) {
			this.empId = empId;
			return this;
		}

		public UserBuilder setEmpName(String empName) {
			this.empName = empName;
			return this;
		}

		public UserBuilder setEmpMail(String empMail) {
			this.empMail = empMail;
			return this;
		}

		public User build() {
			User user = new User(this);
			return user;
		}

	}

}
