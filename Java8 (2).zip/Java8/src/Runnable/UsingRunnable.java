package Runnable;

public class UsingRunnable  {
	
	public static void main(String[] args) {
		
		Runnable r1 = () -> { 
			
			for(int i= 1 ; i<=20; i++) {
				
				System.out.println(i*5);
			}
			
		};
		
		r1.run();
		
	}

}
