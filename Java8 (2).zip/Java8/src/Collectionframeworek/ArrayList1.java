package Collectionframeworek;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ArrayList1 {
	public static void main(String[] args) {

		List<Employee> list = Arrays.asList(
				new Employee(1, "Danny", "Danny@gamil.com",23),
				new Employee(2, "Ram", "ram@gmail.com",45),
				new Employee(2, "shan", "shan@gmail.com",78));
		
		List<Employee> l1 = list.stream().filter(e -> e.getMarks() > 50).collect(Collectors.toList());
		
		System.out.println(l1);
		
		
	}

}
