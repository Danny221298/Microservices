package Singleton;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Signleton1 {
	public static void main(String[] args) throws NoSuchMethodException, SecurityException, InstantiationException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		Singleton s1 = Singleton.getSingleton();
		System.out.println(s1.hashCode());
		/*
		 * Singleton s2 = Singleton.getSingleton(); System.out.println(s2.hashCode());
		 */

		Constructor<Singleton> con = Singleton.class.getDeclaredConstructor();
		con.setAccessible(true);
		Singleton s2 = con.newInstance();
		System.out.println(s2.hashCode());

		/*
		 * Singleton s1 = Singleton.getSingleton(); System.out.println(s1); Singleton s2
		 * = Singleton.getSingleton(); System.out.println(s2);
		 */
	}

}
