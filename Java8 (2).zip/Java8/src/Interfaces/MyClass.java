package Interfaces;

public class MyClass {
	
	public static  void show() {
		
		for(int i  =1 ; i<20 ; i++) {
			
			System.out.println(i * 5);
		}
	}

	public static void main(String[] args) {

		
		
		 Inf1 l1 = MyClass::show;
		 l1.meth1();
		 

	}

}
