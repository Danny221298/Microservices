package Interfaces;

public class Main2 extends MyClass {

	public static void main(String[] args) {

		String s1[] = { "Ganesh" };
		String s2[] = { "Rameez" };

	}

}
