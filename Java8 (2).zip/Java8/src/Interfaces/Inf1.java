package Interfaces;

@FunctionalInterface
public interface Inf1 {
	
	int age=45;
	void meth1();
	

}
