import java.util.Scanner;

public class Fact {
	public static void main(String[] args) {

		int a = 343;
		int b = 0;
		while (a != 0) {

			int r = a % 10;
			b = b * 10 + r;
			a = a / 10;
		}

	}

}
