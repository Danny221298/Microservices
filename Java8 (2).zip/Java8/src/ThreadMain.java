
public class ThreadMain {

	public static void main(String[] args) {
		
		Runnable t22 = ()->{
			
			System.out.println("Hello Java Users");
		};
		
		
		Thread t1 = new Thread(t22);
		t1.start();
	}

}
