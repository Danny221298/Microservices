package FlatMap;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMap1 {
	public static void main(String[] args) {
		List citylist = Arrays.asList("delhi", "mumbai", "hyderabad", "ahmedabad", "indore", "patna"). 
				stream(). map(String::toUpperCase).filter(a -> a.startsWith("H")).collect(Collectors.toList());
		
		System.out.println(citylist);

		
		
	
	}

}
