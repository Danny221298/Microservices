import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class exp {
	public static void main(String[] args) {

		int a1[] = {23,21, 45, 67, 22,21 };
		
		int k =3;
		int sum = 0;
		
		int max1,max2;

		HashSet<Integer> h1 = new HashSet<>();
		
		List<Integer> l1 = Arrays.stream(a1).filter(a-> !h1.add(a)).boxed().collect(Collectors.toList());
		
		Integer l2 = Arrays.stream(a1).distinct().boxed().sorted(Comparator.reverseOrder()).findFirst().get();
		
		Integer l3 = Arrays.stream(a1).distinct().boxed().sorted(Comparator.naturalOrder()).findFirst().get();
		
		Integer l4 = Arrays.stream(a1).boxed().distinct().sorted(Comparator.reverseOrder()).skip(k-1).findFirst().get();
		
		System.out.println(l1 + ", " + l2 + ", " + l3 + ", " + l4);
		
		
		for(int  i = 0 ; i<a1.length; i++) {
			
			 sum = sum +a1[i];
			
		}
		
		System.out.println(sum);

	}

}
