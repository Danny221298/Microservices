import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

abstract class SumOfOddNum {

	abstract void add();

	public static void main(String[] args) {

		List<Integer> l1Integers = Arrays.asList(23, 21, 45, 44, 67, 20);

		List<Integer> l2Integer = l1Integers.stream().filter(a -> a % 2 == 0).collect(Collectors.toUnmodifiableList());

		System.out.println(l2Integer);

	}

}
