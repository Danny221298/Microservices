package Inheritance;

class A {

	public void m1() {
		System.out.println("Class A");
	}
}

class B extends A {

	public void m1() {
		System.out.println("Class B");
	}
}

public class ClassCalling {
	
	public static void main(String[] args) {
		
		A a = new B();
		a.m1();
		
		
	}

}
