import java.util.Arrays;
import java.util.List;

public class FindDuplicateFrom2Arrays {
	
	public static void main(String[] args) {
		
		int arr[]= {22,12,34,54,56};
		
		int arr1[]= {23,45,22,12,76};
		
		
		List<Integer> a1 = Arrays.stream(arr).filter(num -> Arrays.stream(arr1)
				.anyMatch(num1 -> num1 == num)).boxed().toList();
		
		System.out.println(a1);
		
	}

}
