package List;

import java.util.ArrayList;
import java.util.List;

public class ListwithFinal {
	
	public static void main(String[] args) {
		
		final List<String> l1 = new ArrayList<String>();
		
		l1.add("L!");
		l1.add("L2");
		
		System.out.println(l1);
		
		//l1 = new ArrayList<String>;
		
		// we cant reference list to when list declare as final
	}

}
