package List;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class failfast {
	
	public static void main(String[] args) {
		
		List<String> l1 = new ArrayList<String>();
		
		l1.add("A");
		l1.add("B");
		
		Iterator<String> t1 = l1.iterator();
		
		while(t1.hasNext()) {
			
			String e = t1.next();
			System.out.println(e);
			l1.add("C");
 		}
		
	}

}
