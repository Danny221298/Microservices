package List;

import java.util.List;

public class functionalProgramming {
	
	public static void main(String[] args) {
		
		List<Integer> numIntegers = List.of(23,45,32,44,66,76,88);
		
		printNum(numIntegers);
	}
	
	public static void printNum(List<Integer> numIntegers) {
		
		for(int num : numIntegers) {
			
			System.out.println(num);
		}
		
	}
	
	
	

}
