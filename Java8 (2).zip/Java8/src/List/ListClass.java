package List;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class ListClass {

	
	public static void main(String[] args) {
		
		List<Integer> l1 = List.of(12,34,21,54,67,87);
		
		Integer l2 = l1.stream().filter(num ->num%2==0).reduce(Integer::sum).get();
		
		System.out.println(l2);
		
		Predicate<Integer> l1Predicate = new Predicate<Integer>() {
			
			@Override
			public boolean test(Integer t) {
				// TODO Auto-generated method stub
				return false;
			}
		};
		
		Consumer<Integer> l2Consumer = new Consumer<Integer>() {
			
			@Override
			public void accept(Integer t) {
				// TODO Auto-generated method stub
				
			}
		};
		
		Supplier<Integer> l2Supplier = new Supplier<Integer>() {
			
			@Override
			public Integer get() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		
		Function<Integer, Integer> l2Function = new Function<Integer, Integer>() {
			
			@Override
			public Integer apply(Integer t) {
				// TODO Auto-generated method stub
				return null;
			}
		};
 	}
}
