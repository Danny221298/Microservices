package List;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UnModifibleList {

	public static void main(String[] args) {
		
		List<String> s = new ArrayList<String>();
		
		s.add("Stack");
		s.add("OverFlow");
		
		List<String> s2 = Collections.unmodifiableList(s);
		
		System.out.println("Unmodifiable list " +s2);
		
		s2.add("MySql");
		
		System.out.println(s2);
		
		
		List< Integer> l2Integers = List.of(23,21,34,5,67,78);
		
		Integer l3Integers = l2Integers.stream().min((i1,i2)->i1.compareTo(i2)).get();
		
		System.out.println();
	}

}
