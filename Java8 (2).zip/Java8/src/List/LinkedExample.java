package List;

import java.util.Hashtable;
import java.util.LinkedList;

public class LinkedExample {
	
	public static void main(String[] args) {
		
		LinkedList<Integer> n1 = new LinkedList<>();
		
		Hashtable<Integer,Integer> hashtable = new Hashtable<>();
	}

}
