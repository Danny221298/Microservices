package MethodeRefrence1;

@FunctionalInterface
public interface f2 {

	public abstract void hello();

}
