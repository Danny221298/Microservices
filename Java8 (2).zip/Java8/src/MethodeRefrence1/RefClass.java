package MethodeRefrence1;

public class RefClass {
	
	public void print() {
		
		System.out.println("Java is good but Java developer is the Best");
	}
	
	public static void main(String[] args) {
		
		RefClass r1Class = new RefClass();
		f2 s = r1Class::print;
		
		s.hello();
	}

}
