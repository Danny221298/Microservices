package interviewcode;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Java8StreamPrograms {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		List<Student> studentList = Stream.of(
				new Student(1, "Rohit", 30, "Male", "Mechanical Engineering", "Mumbai", 122,
						Arrays.asList("+912632632782", "+1673434729929")),
				new Student(2, "Pulkit", 56, "Male", "Computer Engineering", "Delhi", 67,
						Arrays.asList("+912632632762", "+1673434723929")),
				new Student(3, "Ankit", 25, "Female", "Mechanical Engineering", "Kerala", 164,
						Arrays.asList("+912632633882", "+1673434709929")),
				new Student(4, "Satish Ray", 30, "Male", "Mechanical Engineering", "Kerala", 26,
						Arrays.asList("+9126325832782", "+1671434729929")),
				new Student(5, "Roshan", 23, "Male", "Biotech Engineering", "Mumbai", 12,
						Arrays.asList("+012632632782")),
				new Student(6, "Chetan", 24, "Male", "Mechanical Engineering", "Karnataka", 90,
						Arrays.asList("+9126254632782", "+16736784729929")),
				new Student(7, "Arun", 26, "Male", "Electronics Engineering", "Karnataka", 324,
						Arrays.asList("+912632632782", "+1671234729929")),
				new Student(8, "Nam", 31, "Male", "Computer Engineering", "Karnataka", 433,
						Arrays.asList("+9126326355782", "+1673434729929")),
				new Student(9, "Sonu", 27, "Female", "Computer Engineering", "Karnataka", 7,
						Arrays.asList("+9126398932782", "+16563434729929", "+5673434729929")),
				new Student(10, "Shubham", 26, "Male", "Instrumentation Engineering", "Mumbai", 98,
						Arrays.asList("+912632646482", "+16734323229929")))
				.collect(Collectors.toList());

		// Map And flat map

		List<String> s1 = studentList.stream().flatMap(s -> s.getContacts().stream()).collect(Collectors.toList());
//		System.out.println(s1);

		// Find student who rank between 50 and 100
		List<Student> a1 = studentList.stream().filter(a -> a.getRank() > 50 && a.getRank() < 100)
				.collect(Collectors.toList());
//		System.out.println("a1");

		// find student who's from karnataka and sorted by there name
		List<Student> a2 = studentList.stream().filter(a -> a.getCity().equals("Karnataka"))
				.sorted(Comparator.comparing(Student::getFirstName)).collect(Collectors.toList());
//		System.out.println("a2");

		// find department name
		List<String> a3 = studentList.stream().map(Student::getDept).collect(Collectors.toList());
//		System.out.println("a3");

		// find the contacts
		List<String> a4 = studentList.stream().flatMap(s -> s.getContacts().stream()).distinct()
				.collect(Collectors.toList());
//		System.out.println("a4");

		// Gorupby department name

		Map<String, List<Student>> a9 = studentList.stream().collect(Collectors.groupingBy(Student::getDept));
//		System.out.println("a9");

		// Group the student by there department name and count
		Map<String, Long> a5 = studentList.stream()
				.collect(Collectors.groupingBy(Student::getDept, Collectors.counting()));
		//System.out.println(a5);

		// find the average age OF male and female students
		Map<String, Double> a6 = studentList.stream()
				.collect(Collectors.groupingBy(Student::getGender, Collectors.averagingInt(Student::getAge)));
//		System.out.println("a6");

		// Find the highest rank in each department
		Map<String, Optional<Student>> a7 = studentList.stream().collect(
				Collectors.groupingBy(Student::getDept, Collectors.minBy(Comparator.comparing(Student::getRank))));
//		System.out.println("a7");

		// find out second highest rank
		Student a8 = studentList.stream().sorted(Comparator.comparing(Student::getRank)).skip(1).findFirst().get();
//		System.out.println("a8");

		List<String> a = studentList.stream().map(Student::getFirstName).sorted().toList();

//		System.out.println("a");

		// Sort using Student Name

		List<Student> listStudents = studentList.stream().sorted(Comparator.comparing(Student::getFirstName)).toList();
//		System.out.println("listStudents");

		// Get 2nd rank
		Student listStudents2 = studentList.stream().sorted(Comparator.comparing(Student::getRank).reversed()).skip(1)
				.findFirst().get();
//		System.out.println("List 2nd Highest " + "listStudents2");

		List<String> listStudents3 = studentList.parallelStream().map(Student::getFirstName).toList();
//		System.out.println(listStudents3);

		// find out student and there department name

		Map<String, String> map = new HashMap<>();
		for (Student s10 : studentList) {
			map.put(s10.getFirstName(), s10.getDept());
		}
		for (Map.Entry<String, String> mp : map.entrySet()) {

//			System.out.println("Student Name :" + mp.getKey() + " & Departement name :" + mp.getValue());
		}

	
	//Count student who belongs ro mech dept
		long c1 = studentList.stream().filter(e->e.getDept().equals("Mechanical Engineering")).count();
	//	System.out.println(c1);
	
	//Avg age
	
	double c2 = studentList.stream().collect(Collectors.averagingDouble(Student::getAge)).longValue();
	//System.out.println(c2);
	
	List<Student> c3 = studentList.stream().sorted(Comparator.comparing(Student::getAge).reversed()).toList();
	
	//System.out.println(c3);
	
	Map<String ,Double> c4 = studentList.stream().collect(Collectors.groupingBy(Student::getDept ,Collectors.averagingDouble(Student::getAge)));
	
	//System.out.println(c4);

	List<Student> list2 = studentList.stream().sorted(Comparator.comparing(Student::getRank).reversed()).skip(3).toList();

	//System.out.println(list2);
	
	List<Integer> list3 = studentList.stream().filter(num->num.getAge()>30).map(s->s.getRank() +20).collect(Collectors.toList());
	
	//System.out.println(list3);
	
	List<Student> list4 = studentList.stream().sorted(Comparator.comparing(Student::getAge).thenComparing(Student::getRank)).toList();
	
	//System.out.println(list4);
	
	Map<String, Long> list5 = studentList.stream().filter(num->num.getAge()>20).collect(Collectors.groupingBy(Student::getDept,Collectors.counting()));
	
	//System.out.println(list5);
	
	//Rank is less that 100 & age is greater than 30 sorted by name
	List<String> list6= studentList.stream().filter(name-> name.getRank()<=100 && name.getAge()>20).map(name1->name1.getFirstName()).sorted(Comparator.naturalOrder()).toList();
	
	System.out.println(list6);
	}
}