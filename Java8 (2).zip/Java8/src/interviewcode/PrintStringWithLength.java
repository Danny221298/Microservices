package interviewcode;

import java.util.Arrays;
import java.util.List;

public class PrintStringWithLength {

	public static void main(String[] args) {

		List<String> l1 = Arrays.asList("Apple", "Java", "Python1");

		l1.stream().map(name -> name + " = " + name.length()).forEach(System.out::println);

	}
}