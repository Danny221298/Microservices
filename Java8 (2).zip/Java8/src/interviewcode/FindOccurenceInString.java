package interviewcode;

import java.util.HashMap;
import java.util.Map;

public class FindOccurenceInString {

	public static void findOccurence(String name) {

		Map<Character, Integer> charmap = new HashMap<Character, Integer>();

		char[] ch = name.toCharArray();
		for (char c : ch) {

			if (charmap.containsKey(c)) {
				charmap.put(c, charmap.get(c) + 1);
				
			} else {
				charmap.put(c, 1);
			}
		}

		System.out.println(charmap);

	}

	public static void main(String[] args) {

		findOccurence("Java");
	}
}
