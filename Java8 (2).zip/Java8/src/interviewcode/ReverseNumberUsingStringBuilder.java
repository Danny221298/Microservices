package interviewcode;

public class ReverseNumberUsingStringBuilder {
	
	public static void main(String[] args) {
		
		int num = 313;
		
		int reverse;
		
		StringBuilder str = new StringBuilder(String.valueOf(num));
		
		reverse = Integer.valueOf(str.reverse().toString());
		
		if(num==reverse) {
			
			System.out.println("palimdrome");
		}
		
		else {
			System.out.println("not");
		}

	}
	

}
