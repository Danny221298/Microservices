package interviewcode;

import java.util.Arrays;
import java.util.List;

public class FindingTheCountUsingStream {
	
	public static void main(String[] args) {
		
		List<String> s = Arrays.asList("apple" ,"Banana","Apple" );
		
		long a = s.stream().filter(x->x.equalsIgnoreCase("apple")).count();
		
		System.out.println(a);
	}
	
	

}
