package interviewcode;

import java.util.Optional;

public class OptionalClassUse {

	public static void main(String[] args) {

		String str = "Danny";

		Optional<String> opt = Optional.ofNullable(str);

		if(opt.isEmpty()) {
			System.out.println("String is enpty");
		}
		else {
			System.out.println(str);
		}

	}

}
