package interviewcode;

public class FindPowerOf {

	public static int power(int a, int b) {

		int power1 = 1;

		for (int i = 0; i <= b; i++) {

			power1 = power1 * a;

			
		}
		return power1;
	}

	public static void main(String[] args) {

		System.out.println(power(2, 3));

	}

}
