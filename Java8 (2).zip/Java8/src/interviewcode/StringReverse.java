package interviewcode;

public class StringReverse {

	String str = "Maven";
	String str1 = "";

	void reverseString() {

		for (int i = str.length() - 1; i >= 0; i--) {

			str1 = str1 + str.charAt(i);
		}
		System.out.println(str1);
	}

	public static void main(String[] args) {

		StringReverse s = new StringReverse();
		s.reverseString();

	}

}
