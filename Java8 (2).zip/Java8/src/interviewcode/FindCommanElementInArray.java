package interviewcode;

import java.util.Arrays;
import java.util.List;

public class FindCommanElementInArray {

	public static void main(String[] args) {

		int arr[] = { 20, 34, 1, 50 };
		int arr2[] = { 10, 59, 50, 31,34 };

	List<Integer> l2List = Arrays.stream(arr).filter(num -> Arrays.stream(arr2).anyMatch(num2 -> num2==num)).boxed().toList();
	System.out.println(l2List);
	
	
	for(int i = 0 ; i<arr.length; i++) {
		
		for(int j=0 ;j<arr2.length;j++) {
			
			if(arr[i] == arr2[j]) {
				
				System.out.println(arr[i]);
			}
		}
		
	}
	}

}
