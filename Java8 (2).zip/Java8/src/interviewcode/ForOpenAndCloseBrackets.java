package interviewcode;

import java.util.Stack;

public class ForOpenAndCloseBrackets {

	public static void main(String[] args) {

		String s = "{}()[]";
		boolean status = validate(s);
		System.out.println(s);
	
	System.out.println(status);
	}

	public static boolean validate(String s) {

		Stack<Character> s1 = new Stack<>();
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);

			if (ch == '}') {
				if (s1.peek() == '{') {
					s1.pop();

				} else {
					return false;
				}
			} else if (ch == ')') {
				if (s1.peek() == '(') {
					s1.pop();
				} else {
					return false;
				}
			} else if (ch == ']') {
				if (s1.peek() == '[') {
					s1.pop();
				} else {
					return false;
				}
			} else {
				s1.push(ch);
			}

		}
		if (s1.size() == 0) {
			return true;
		}
		return false;
	}
}