package interviewcode;

import java.util.Arrays;
import java.util.stream.Collectors;

public class ConvertFirstLetterToUpperCase {
	
	public static void main(String[] args) {
		
		String str = "java is good lang";
		
		String word[] = str.split(" ");
		
		String map = Arrays.stream(word).map(name -> name.substring(0,1).toUpperCase()+name.substring(1))
				.collect(Collectors.joining(" "));
		
		System.out.println(map);
	}

}
