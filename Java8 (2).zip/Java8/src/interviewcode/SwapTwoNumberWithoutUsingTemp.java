package interviewcode;

public class SwapTwoNumberWithoutUsingTemp {
	
	public static void swap(int a,int b) {
		
		 a = a+b;
		 b=a-b;
		 a=a-b;
		 
		 System.out.println("Value of B is :" + a + " Value of B is :" +b);
	}
	
	public static void main(String[] args) {
		
		swap(5,6);
		
	}

}
