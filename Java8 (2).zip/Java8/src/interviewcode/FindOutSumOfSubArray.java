package interviewcode;

public class FindOutSumOfSubArray {
	
	public static void main(String[] args) {
		
		int arr[] = {1,2,2,3,4,5};
		int k =4;
		int result = 0;
		
		for(int i =0 ;i<arr.length; i++) {
			
			int sum =0;
			
			for( int j = i; j<arr.length; j++) {
				
				sum =sum+arr[j];
				
				if(sum==k) {
					
					result++;
				}
			}
			
		}
		
		System.out.println("Arrays of sum up to " + k + "  is " +result);
	}

}
