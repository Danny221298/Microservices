package interviewcode;

public class GenrateOPT {
	
	public static void main(String[] args) {
		
		int d = (int)(Math.random()*9000) + 1000;
		
		
		
		System.out.println(d);
	}

}
