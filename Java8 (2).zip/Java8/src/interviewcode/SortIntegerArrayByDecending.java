package interviewcode;

import java.util.Arrays;

public class SortIntegerArrayByDecending {
	
	public static void main(String[] args) {
		 
		String arr[]= {"34","2","6","9","78"};
		
		Arrays.sort(arr, (num,num2) -> (num2+num).compareTo(num+num2));
		
		String str="";
		
		for(String s :arr) {
			str =str+s;
			
		}
		
		System.out.println(str);
	}

}
