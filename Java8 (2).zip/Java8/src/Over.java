class O {

	public void msg() {

		System.out.println("Hello");

	}
}

class O2 extends O {

	public void msg() {

		System.out.println("Hi");
	}
}

public class Over {

	public static void main(String[] args) {

		O o = new O2();
		
		o.msg();
	}
}
