package thisUsing;

public class ThisClass {

	int a = 40;

	public static void main(String[] args) {

		int a = 20;
		ThisClass t1 = new ThisClass();
		System.out.println(t1.add(a));
	}

	public int add(int a) {

		this.a = 100;
		return a;
	}

}
