import java.util.Scanner;

public class Hello {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 numbers");
		int a = sc.nextInt();
		int b = sc.nextInt();
		
		System.out.println("Enter your option for switch");
		String option = sc.next();
		
		switch(option) {
		case "Add":
			System.out.println(a+b);
			break;
		}
	}

}
