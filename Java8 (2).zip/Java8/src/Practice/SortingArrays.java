package Practice;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class SortingArrays {
	public static void main(String[] args) {

		int a1[] = { 23, 43, 21, 11, 12, 23, 6 };

		for (int i = 0; i < a1.length; i++) {
			for (int j = i; j < a1.length; j++) {

				if (a1[i] > a1[j]) {

					int temp = a1[i];
					a1[i] = a1[j];
					a1[j] = temp;
				}
			}
		}

		System.out.println("Array After sorting");

		for (int i = 0; i < a1.length; i++) {

			System.out.println(a1[i]);
		}

		Integer l2List = Arrays.stream(a1).boxed().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();

		System.out.println(l2List);

		Set<Integer> s1Integers = new HashSet<Integer>();

		List<Integer> l1List = Arrays.stream(a1).filter(a -> !s1Integers.add(a)).boxed().toList();

		System.out.println(l1List);

		int max1, max2;

		max1 = max2 = a1[0];

		for (int i = 0; i < a1.length; i++) {

			if (a1[i] > max1) {

				max2 = max1;
				max1 = a1[i];

			} else {

				max2 = a1[i];
			}
		}

		System.out.println("2nd last max is :" + max2);

		List<String> l3List = Arrays.stream(a1).boxed().map(a -> a + "").filter(a -> a.startsWith("1")).toList();

		System.out.println(l3List);

		List<Integer> l4Integers = Arrays.stream(a1).boxed().filter(a -> a % 2 == 0).toList();

		System.out.println(l4Integers);

		List<Integer> s1 = List.of(12, 23, 45, 67, 89, 43);

		List<Integer> s2 = List.of(12, 23, 45, 67, 89, 41);

		List<Integer> s3 = Stream.concat(s1.stream(), s2.stream()).distinct().toList();

		System.out.println(s3);

	}

}
