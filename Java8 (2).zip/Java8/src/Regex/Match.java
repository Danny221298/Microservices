package Regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Match {

	public static void main(String[] args) {

		String regex = "ad";

		Pattern p = Pattern.compile(regex);

		Matcher m = p.matcher("ad");
		boolean match = m.matches();

		if (match) {

			System.out.println(match);
		} else {
			System.out.println("Not match string");
		}

	}
}
