package Strings;

public class RreplaceVowelWithStar {

	public static void main(String[] args) {

		String str = "Java";

		 
		String str2 =str.replaceAll("[aeiouAEIOU]", "*");
		
		System.out.println(str2);
		
	}

}
