package Strings;

public class RemoveDuplicatesFromTwoDifferentString {

	public static void main(String[] args) {

		String str = "hello java users";

		String str2 = " how are you";

		for (int i = 0; i < str.length(); i++) {

			str2 = str2.replace(str.charAt(i), '\0');

		}
		String s3 = str + str2;

		System.out.println("the string after removing common character  and concatenation is " + s3);

	}

}