package Strings;

public class AddingTheNumbersInString {

	public static void main(String[] args) {

		String str = "Dannny2212";
		int sum = 0;
		char[] c = str.toCharArray();
		for(char ch : c) {
			
			if(Character.isDigit(ch)) {
				
				sum = sum +Character.getNumericValue(ch);
			}
		}
		
		System.out.println(sum);

	}

}
