package Strings;

import java.util.List;

public class VowelFind {

	public static void main(String[] args) {

		System.out.println(vowel("Java User"));
	}

	public static int vowel(String str) {

		int cnt = 0;
		char[] ch = str.toCharArray();

		for (char c : ch) {
			if(List.of('a','e','i').contains(c)) {
				cnt++;
			}
			
		}

		return cnt;
	}

}
