package Colneable;

abstract class AbstractClass {

	public abstract void sound();

	public void categeory() {
		System.out.println("Animal");
	}
}

class Animal extends AbstractClass{

	@Override
	public void sound() {
	System.out.println("Meow");
		
	}
	
	
}

