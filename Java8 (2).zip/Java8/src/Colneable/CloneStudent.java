package Colneable;

class Student1 implements Cloneable {

	private int id;

	private String name;

	public Student1(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Student1 [id=" + id + ", name=" + name + "]";
	}

	public Object clone() throws CloneNotSupportedException {

		return super.clone();
	}
}

public class CloneStudent {

	public static void main(String[] args) {
		try {
			Student1 s1 = new Student1(11, "Sumit");

			Student1 s2 = (Student1) s1.clone();

			System.out.println(s1);
			System.out.println(s2);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

	}

}