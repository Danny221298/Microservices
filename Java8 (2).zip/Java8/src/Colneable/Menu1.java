package Colneable;

public class Menu1 {

	public static void main(String[] args) {
		
		Animal an = new Animal();
		an.categeory();
		an.sound();
	}
}
