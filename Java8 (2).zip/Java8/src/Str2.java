import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Str2 {
	
	public static void main(String[] args) {
		
		String s ="aabbccddff";
		
		int result =count(s);
		
		if (result!=1) {
			System.out.println("Index of non repeating char :" +result);
			
		}else {
			System.out.println("Index repeating char : " +result );
		}
	}

	
	private static int count(String s) {
		
		Map<Character, Integer> map =new LinkedHashMap<>();
		
		for(char c: s.toCharArray()) {
			
			map.put(c, map.getOrDefault(c, 0)+1);
		}
		
		for(Entry<Character, Integer> entry:map.entrySet()) {
			if(entry.getValue()==1) {
				
				return s.indexOf(entry.getKey());
			}
		}
		return -1;
		
		
	}

}
