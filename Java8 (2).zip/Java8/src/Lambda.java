@FunctionalInterface
interface foo {
	public void draw();
}

public class Lambda {
	public static void main(String[] args) {

		int w = 10;

		foo d2 = () -> {
			System.out.println("Width is :" + w);

		};
		d2.draw();
	}
}
