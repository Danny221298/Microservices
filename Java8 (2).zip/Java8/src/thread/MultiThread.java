package thread;

public class MultiThread implements Runnable {

	@Override

	public void run() {

		synchronized (this) {

			for (int i = 1; i <= 10; i++) {

				System.out.println(i * 99);

				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {

					e.printStackTrace();
				}
			}

		}
	}

	public static void main(String[] args) {

		MultiThread t1 = new MultiThread();

		Thread th2 = new Thread(t1);

		Thread th3 = new Thread(t1);

		th2.start();

		th3.start();

	}

}
