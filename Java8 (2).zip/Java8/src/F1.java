public class F1 extends Thread {

	public static void main(String[] args) {

		String s1 = "Danny";
		String s2 = new String("Danny");
		
		System.out.println(s1.equals(s2));
		
		
	}
}
