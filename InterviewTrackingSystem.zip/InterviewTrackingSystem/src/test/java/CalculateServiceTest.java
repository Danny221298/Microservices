import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.services.CalculatorService;

@SpringBootTest
public class CalculateServiceTest {

	
	
	@Test
	public void addTwoNumTest() {
		
		int result =CalculatorService.addTwoNum(12,23);
		
		int expected = 25;
		
		Assert.assertEquals(result, expected);
		
	}

}
