package com.capgemini.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import com.capgemini.entities.Candidate;
import com.capgemini.entities.InterviewSchedule;
import com.capgemini.entities.PanelMember;
import com.capgemini.exception.CandidateNotFoundException;
import com.capgemini.exception.NoSuchInterviewIdException;
import com.capgemini.exception.NoSuchPanelIdException;

@SpringBootTest
class HRPanelServiceImplTest 
{
	//reference variable for AdministratorService
	@Autowired
	private AdministratorService administratorService;
	
	
	
	//reference variable for ApplicationContext
	@Autowired
	private ApplicationContext context;
	
	//reference variable for HRPanelService
	@Autowired
	private HRPanelService hservice;
	
	

	//test case for view candidate by Id
	@Test
	void testFindCandidateByIdReturnCandidate() throws CandidateNotFoundException 
	{
		// 1,"Aman","Java","Python","null","BE","Analyst","3 months","Mumbai"
		Candidate expected = context.getBean(Candidate.class);
		expected.setCandidateId(1);
		expected.setCandidateName("Aman");
		expected.setPrimarySkill("Java");
		expected.setSecondarySkill("Python");
		expected.setExperience("null");
		expected.setQualification("BE");
		expected.setDesignation("Analyst");
		expected.setNoticePeriod("3 months");
		expected.setLocation("Mumbai");

		administratorService.addCandidate(expected);

		Candidate actual = hservice.viewCandidateById(expected.getCandidateId());
		assertEquals(expected.getCandidateId(), actual.getCandidateId());
		assertEquals(expected.getCandidateName(), actual.getCandidateName());
		assertEquals(expected.getPrimarySkill(), actual.getPrimarySkill());
		assertEquals(expected.getSecondarySkill(), actual.getSecondarySkill());
		assertEquals(expected.getExperience(), actual.getExperience());
		assertEquals(expected.getQualification(), actual.getQualification());
		assertEquals(expected.getDesignation(), actual.getDesignation());
		assertEquals(expected.getNoticePeriod(), actual.getNoticePeriod());
		assertEquals(expected.getLocation(), actual.getLocation());
	}
	
		// test case for view PanelMember by Id
		@Test
		void testFindPanelMemberByIdReturnPanelMember() throws NoSuchPanelIdException 
		{
			
			// 1,"HR","Mumbai",1000,Lakshmi,"HR","FINANCE",1,"Aman","Java","Python","null","BE","Analyst","3 months","Mumbai"
			PanelMember expected = context.getBean(PanelMember.class);
			expected.setPanelId(1);
			expected.setEmployeeType("HR");
			expected.setLocation("Mumbai");
			expected.getEmployee().setEmployeeId(1000);
			expected.getEmployee().setEmployeeName("LAKSHMI");
			expected.getEmployee().setDepartment("HR");
			expected.getEmployee().setDesignation("FINANCE");
			expected.getCandidate().setCandidateId(1);
			expected.getCandidate().setCandidateName("Aman");
			expected.getCandidate().setPrimarySkill("Java");
			expected.getCandidate().setSecondarySkill("Python");
			expected.getCandidate().setExperience("null");
			expected.getCandidate().setQualification("BE");
			expected.getCandidate().setDesignation("Analyst");
			expected.getCandidate().setNoticePeriod("3 months");
			expected.getCandidate().setLocation("Mumbai");

			administratorService.addPanelMember(expected);
			
			PanelMember actual =hservice.viewPanelMemberById(expected.getPanelId());
			
			assertEquals(expected.getPanelId(),actual.getPanelId());
			assertEquals(expected.getEmployeeType(),actual.getEmployeeType());
			assertEquals(expected.getLocation(),actual.getLocation());
			assertEquals(expected.getEmployee().getEmployeeId(),actual.getEmployee().getEmployeeId());
			assertEquals(expected.getEmployee().getEmployeeName(),actual.getEmployee().getEmployeeName());
			assertEquals(expected.getEmployee().getDepartment(),actual.getEmployee().getDepartment());
			assertEquals(expected.getEmployee().getDesignation(),actual.getEmployee().getDesignation());
			assertEquals(expected.getCandidate().getCandidateId(),actual.getCandidate().getCandidateId());
			assertEquals(expected.getCandidate().getCandidateName(),actual.getCandidate().getCandidateName());
			assertEquals(expected.getCandidate().getPrimarySkill(),actual.getCandidate().getPrimarySkill());
			assertEquals(expected.getCandidate().getSecondarySkill(),actual.getCandidate().getSecondarySkill());
			assertEquals(expected.getCandidate().getExperience(),actual.getCandidate().getExperience());
			assertEquals(expected.getCandidate().getQualification(),actual.getCandidate().getQualification());
			assertEquals(expected.getCandidate().getDesignation(),actual.getCandidate().getDesignation());
			assertEquals(expected.getCandidate().getNoticePeriod(),actual.getCandidate().getNoticePeriod());
			assertEquals(expected.getCandidate().getLocation(),actual.getCandidate().getLocation());
		}
		
		
		void testFindUpdateCandidateHRRating() throws NoSuchInterviewIdException
		{
			InterviewSchedule expected =  context.getBean(InterviewSchedule.class);
			
			
			
		}
		
		
		//test case for CandidateNotFoundException
		@Test
		public void testShouldThrowCandidateNotFoundException()
		{
			@SuppressWarnings("unused")
			CandidateNotFoundException exception = assertThrows(CandidateNotFoundException.class,()->{ hservice.viewCandidateById(111);});
		}
		
		//test case for NoSuchPanelIdException
		@Test	
		public void testShouldThrowNoSuchPanelIdException()
		{
			@SuppressWarnings("unused")
			NoSuchPanelIdException exception = assertThrows(NoSuchPanelIdException.class,()->{ hservice.viewPanelMemberById(111);});
		}
		
	
	

}
