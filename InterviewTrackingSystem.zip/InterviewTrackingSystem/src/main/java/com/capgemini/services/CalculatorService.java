package com.capgemini.services;

public class CalculatorService {
	
	public static int addTwoNum(int a ,int b) {
		return a+b;
	}

}
