package com.capgemini.services;

import java.util.List;

import javax.mail.MessagingException;

import org.springframework.mail.javamail.JavaMailSender;

import com.capgemini.entities.Candidate;
import com.capgemini.entities.Employee;
import com.capgemini.entities.InterviewSchedule;
import com.capgemini.entities.PanelMember;
import com.capgemini.entities.User;
import com.capgemini.exception.CandidateNotFoundException;
import com.capgemini.exception.EmployeeByIdNotFoundException;
import com.capgemini.exception.EmployeeNotFoundException;
import com.capgemini.exception.NoSuchCandidateException;
import com.capgemini.exception.NoSuchInterviewIdException;
import com.capgemini.exception.NoSuchInterviewScheduleException;
import com.capgemini.exception.NoSuchPanelIdException;

public interface AdministratorService
{
	public boolean addCandidate(Candidate candidate);
	
	public Candidate viewCandidateById(int candidateId) throws NoSuchCandidateException;
	
	public boolean scheduleInterview(InterviewSchedule interviewSchedule);
	
	public List<Candidate> viewInterviewMemebers()throws CandidateNotFoundException;  //1
	
	public List<Employee> viewAllEmployee() throws EmployeeNotFoundException;  //2
	
	public List<InterviewSchedule> viewInterviewSchedules()throws NoSuchInterviewIdException; //3
	
	public boolean updateInterviewScheduleOfFinalStatus(InterviewSchedule interviewSchedule);		//update candidate adminRating
	
	
	
	public InterviewSchedule viewInterviewById(int interviewId) throws NoSuchInterviewScheduleException;

//	public boolean cancelInterview(int interviewId, boolean deleteStatus) throws NoSuchInterviewScheduleException;
	
	public boolean cancelInterview(int interviewId) throws NoSuchInterviewScheduleException;
	
	public List<InterviewSchedule> activeInterview();
	
	public List<InterviewSchedule> inactiveInterview();
	
	public boolean addPanelMember(PanelMember panelMember);
	
	public PanelMember viewPanelMemberById(int panelId) throws NoSuchPanelIdException;				//view panel member by id
	
	
	public Employee searchEmployeeById(int employeeId) throws EmployeeByIdNotFoundException;
	
	public List<Employee> searchEmployeeByName(String employeeName)throws EmployeeNotFoundException;
	
	public boolean deletePanelMember(int panelId) throws NoSuchPanelIdException;
	
	public List<PanelMember> activePanelMember();
	
	public List<PanelMember> InActivePanelMember();
	
	public List<PanelMember> listAllExistingPanelMember();
	
	public boolean addEmployee(Employee employee);
	
	public boolean loginUser(User user);
	
	public  User registration(User user);
	
	//public List<InterviewSchedule> viewCandidateByTechRating(String techRating)throws CandidateNotFoundException;
	
	//public List<Candidate> viewInterviewMemebers() throws CandidateNotFoundException;					//list all candidates

	//public boolean updateCandidateHrRating(InterviewSchedule interviewSchedule);		//update candidate hrRating

	//public Candidate viewCandidateById(int candidateId) throws CandidateNotFoundException;			//view candidate by id

	//public PanelMember viewPanelMemberById(int panelId) throws NoSuchPanelIdException;				//view panel member by id
	
	//public List<PanelMember> listAllExistingPanelMember();
	


	
	public void mailService(JavaMailSender javaMailSender);
	public void sendInterviewScheduledEmail(InterviewSchedule interviewSchedule) throws MessagingException;
	public void sendInterviewStatusEmail(InterviewSchedule interviewSchedule);
}