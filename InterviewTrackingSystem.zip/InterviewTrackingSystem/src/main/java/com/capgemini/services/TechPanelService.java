package com.capgemini.services;

import java.util.List;

import com.capgemini.entities.Candidate;
import com.capgemini.entities.InterviewSchedule;
import com.capgemini.entities.PanelMember;
import com.capgemini.entities.User;
import com.capgemini.exception.CandidateNotFoundException;
import com.capgemini.exception.NoSuchInterviewIdException;
import com.capgemini.exception.NoSuchPanelIdException;

public interface TechPanelService 
{

	public List<Candidate> viewInterviewMemebers()throws CandidateNotFoundException; 			//list all candidates
	
	public boolean updateCandidateTechRating(InterviewSchedule interviewSchedule);		//update candidate techRating
	
	public Candidate viewCandidateById(int candidateId)throws CandidateNotFoundException;			//view candidate by id
	
	public List<PanelMember> listAllExistingPanelMember();
	
	public PanelMember viewPanelMemberById(int panelId) throws NoSuchPanelIdException;		//view panel member by Id
	
	
	public InterviewSchedule viewInterviewScheduleById(int interviewId)throws NoSuchInterviewIdException;

	public List<InterviewSchedule> viewInterviewSchedules()throws NoSuchInterviewIdException;
	
public boolean loginUser(User user);
	
	public  User registration(User user);
}
