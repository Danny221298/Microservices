package com.capgemini.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.entities.Candidate;
import com.capgemini.entities.InterviewSchedule;
import com.capgemini.entities.PanelMember;
import com.capgemini.entities.User;
import com.capgemini.exception.CandidateNotFoundException;
import com.capgemini.exception.NoSuchInterviewIdException;
import com.capgemini.exception.NoSuchPanelIdException;
import com.capgemini.repository.CandidateRepository;
import com.capgemini.repository.InterviewScheduleRepository;
import com.capgemini.repository.PanelMemberRepository;
import com.capgemini.repository.UserRepository;



@Service("HRPanelService")
public class HRPanelServiceImpl implements HRPanelService
{
	//Reference variable of CandidateRepository
	@Autowired
	private CandidateRepository repository;		
	
	//Reference variable of InterviewScheduleRepository
	@Autowired
	private InterviewScheduleRepository interviewRepository;
	
	//Reference variable of PanelMemberRepository
	@Autowired
	private PanelMemberRepository panelRepository;
	
	@Autowired
	private UserRepository repositoryOfLogin;
	
	//Logger Object created
	private static final Logger LOGGER = LoggerFactory.getLogger(AdministratorServiceImpl.class);
	

	@Override
	public boolean loginUser(User user) {
		boolean result = false;
		User user2 = repositoryOfLogin.validateUser( user.getUsername(),user.getPassword());
		if (user2 != null) {
			result = true;

		}
		return result;

	}

	@Override
	public User registration(User user) {
		return repositoryOfLogin.save(user);
	}
	

	@Override
	public List<Candidate> viewInterviewMemebers() throws CandidateNotFoundException 
	{   
		LOGGER.trace("Entering viewInterviewMemebers method");
		List<Candidate> candidates =repository.findAll();
		if(candidates.isEmpty())
		{   
			LOGGER.error("Interview Member Not Found");
			throw new CandidateNotFoundException("No candidates found");
		}
		LOGGER.info("Interview Member Found Successfully");
		return candidates;
	}

	
	


	@Override
	public Candidate viewCandidateById(int candidateId) throws CandidateNotFoundException
	{    
		LOGGER.trace("Entering viewCandidateById method");
		if(repository.existsById(candidateId))
		{   
			LOGGER.info("Candidate Found Successfully");
			return repository.findById(candidateId).get();
		}
		LOGGER.error("Candidate Not Found");
		throw new CandidateNotFoundException("candidate with id "+candidateId +"not found");
	}


	@Override
	public PanelMember viewPanelMemberById(int panelId) throws NoSuchPanelIdException 
	{   
		LOGGER.trace("Entering viewPanelMemberById method");
		if(panelRepository.existsById(panelId))
		{   
			LOGGER.info("Panel Member Found Successfully");
			return panelRepository.findById(panelId).get();
		}
		LOGGER.error("Panel Member Not Found");
		throw new NoSuchPanelIdException("panel with id "+panelId+" not found");
	}
	
	
	
	@Override
	public List<InterviewSchedule> viewCandidateByTechRating(String techRating) throws CandidateNotFoundException 
	{
		LOGGER.trace("Entering viewCandidateByTechRating method");
	    LOGGER.info("Candidate By Interview_Schedule Having TechRating As Selected Found Successfully");
		return interviewRepository.findAllCandidateByTechRating(techRating);
	}

	@Transactional
	@Override
	public boolean updateCandidateHrRating(InterviewSchedule interviewSchedule) {
		LOGGER.trace("Entering updateCandidateHrRating method");
		
		  
		LOGGER.info("Hr Rating Updated Successfully");
		interviewRepository.updateHRRatingInInterviewSchedule(interviewSchedule.getHrRating(), interviewSchedule.getInterviewId());
	
	LOGGER.error("Scheduled Interview Not Found");
	return true;
}

	@Override
	public InterviewSchedule viewInterviewScheduleById(int interviewId) throws NoSuchInterviewIdException {
		LOGGER.trace("Entering viewCandidateById method"); if
		 (interviewRepository.existsById( interviewId)) {
		  LOGGER.info("Candidate Found Successfully"); return
		  interviewRepository.viewById(interviewId); }
		  LOGGER.error("Candidate Not Found"); throw new
		  NoSuchInterviewIdException("candidate with id " + interviewId + "not found");
		
	}
	@Override
	public List<InterviewSchedule> viewInterviewSchedules() throws NoSuchInterviewIdException {
		LOGGER.trace("Entering viewInterviewSchedues method");
		List<InterviewSchedule> interviewSchedules  = interviewRepository.findAll();
		if(interviewSchedules.isEmpty())
		{   
			LOGGER.error("Interview shedules is Not Found");
			throw new NoSuchInterviewIdException("No interview schedules found");
		}
		LOGGER.info("Interview schedules Found Successfully");
		return interviewSchedules;
		
	}

	
		@Override
		public List<PanelMember> listAllExistingPanelMember() {

				LOGGER.trace("Entering Inside listAllExistingPanelMember method");
				LOGGER.info(" All Panel Members Found Successfully");
				return panelRepository.findAll();
			}
			
	
	

}
