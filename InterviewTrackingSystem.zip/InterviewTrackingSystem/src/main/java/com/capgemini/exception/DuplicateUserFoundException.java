package com.capgemini.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class DuplicateUserFoundException extends RuntimeException {
	
	public  DuplicateUserFoundException(String message) {
		super(message);
	}


}
