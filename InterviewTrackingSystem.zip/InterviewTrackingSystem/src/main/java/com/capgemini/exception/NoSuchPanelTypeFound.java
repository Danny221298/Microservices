package com.capgemini.exception;

@SuppressWarnings("serial")
public class NoSuchPanelTypeFound extends Exception
{
	public NoSuchPanelTypeFound(String msg) 
	{
		super(msg);
	}

}
