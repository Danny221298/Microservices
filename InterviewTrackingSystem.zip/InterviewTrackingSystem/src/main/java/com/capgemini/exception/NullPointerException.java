package com.capgemini.exception;

@SuppressWarnings("serial")
public class NullPointerException extends RuntimeException 
{
	public NullPointerException(String message) 
	{
		super(message);
	}


}
