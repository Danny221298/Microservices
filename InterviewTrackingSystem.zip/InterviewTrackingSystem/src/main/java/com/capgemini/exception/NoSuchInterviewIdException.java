package com.capgemini.exception;

@SuppressWarnings("serial")
public class NoSuchInterviewIdException extends Exception
{
	 public NoSuchInterviewIdException(String msg) 
	 {
		 super(msg);
	 }
}
