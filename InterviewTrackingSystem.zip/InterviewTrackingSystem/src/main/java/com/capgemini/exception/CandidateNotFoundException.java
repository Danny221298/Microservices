package com.capgemini.exception;

@SuppressWarnings("serial")
public class CandidateNotFoundException extends Exception
{
	public CandidateNotFoundException(String message)
	{
		super(message);
	}

}



