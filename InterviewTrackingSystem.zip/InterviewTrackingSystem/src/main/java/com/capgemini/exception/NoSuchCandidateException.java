package com.capgemini.exception;

public class NoSuchCandidateException extends RuntimeException {
	public NoSuchCandidateException(String message) {
		super(message);
	}

}
