package com.capgemini.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.entities.InterviewSchedule;

@Repository
public interface InterviewScheduleRepository extends JpaRepository<InterviewSchedule, Integer> 
{
	@Transactional
	@Modifying
	@Query(value = "Update InterviewSchedule i set i.techRating = :techRating where i.interviewId = :interviewId")
	int updateTechRatingInInterviewSchedule(@Param("techRating") String techRating ,@Param("interviewId") int interviewId);

	@Transactional
	@Modifying
	@Query(value = "Update InterviewSchedule i set i.hrRating = :hrRating where i.interviewId= :interviewId")
	int updateHRRatingInInterviewSchedule(@Param("hrRating") String hrRating,@Param("interviewId") int interviewId);

	@Transactional
	@Modifying
	@Query(value = "Update InterviewSchedule i set i.finalStatus = :finalStatus where i.interviewId = :interviewId")
	int updateFinalStatusInInterviewSchedule(@Param("finalStatus") String finalStatus,@Param("interviewId") int interviewId);

//	@Transactional
//	@Modifying
//	@Query(value = "Update InterviewSchedule i set i.deleteStatus = :deleteStatus where i.interviewId = :interviewId")
//	public void softDeleteOfInterviewSchedule(@Param("interviewId") int interviewId,
//			@Param("deleteStatus") boolean deleteStatus);

	@Query(value = "Select i from InterviewSchedule i where i.deleteStatus = false")
	public List<InterviewSchedule> findAllActiveSchedule();

	@Query(value = "Select i from InterviewSchedule i where i.deleteStatus = true")
	public List<InterviewSchedule> findAllInactiveSchedule();
	
	@Query(value="select i from InterviewSchedule i where i.techRating =:techRating")
	public List<InterviewSchedule> findAllCandidateByTechRating(@Param("techRating") String techRating);
	
	@Query(value="Select i From InterviewSchedule i  where i.interviewId=:interviewId")
	public InterviewSchedule viewById(@Param("interviewId") int interviewId);

}
