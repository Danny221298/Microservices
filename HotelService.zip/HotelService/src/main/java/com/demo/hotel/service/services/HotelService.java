package com.demo.hotel.service.services;

import java.util.List;

import com.demo.hotel.service.entities.Hotel;
import com.demo.hotel.service.exceptions.ResourceNotFoundException;

public interface HotelService {
	
	Hotel create(Hotel hotel);
	
	List<Hotel> getAll();
	
	Hotel get(String id) throws ResourceNotFoundException;

}
